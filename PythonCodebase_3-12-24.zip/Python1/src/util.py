mtrR = 0
mtrL = 3

RCONST = 0.98
LCONST = 1.0

RTOPHAT = 0
LTOPHAT = 1

gray = 2000
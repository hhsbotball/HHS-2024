#sys.path.append("/home/kipr/Documents/KISS/User/PyTest/src")
import os, sys
#sys.path.append("/home/kipr/.local/lib/python3.9/site-packages/multipledispatch")
#sys.path.append("/usr/lib/python3.9/dist-packages")
from _kipr import *
from util import *
from multipledispatch import *

#####STRAIGHT MOVEMENTS#####
#STRAIGHT Takes parameters speed (arbitrary) and distance (arbitrary)
@dispatch(int, int)
def straight(speed, dist):
    cmpc(mtrR)
    cmpc(mtrL)
    if speed < 0:
        while gmpc(mtrR) > (dist * -1) and gmpc(mtrL) > (dist * -1):
            mav(mtrR, round(speed * RCONST))
            mav(mtrL, round(speed * LCONST))
            gmpc(mtrR)
            gmpc(mtrL)
    else:
        while gmpc(mtrR) < dist and gmpc(mtrL) < dist:
            mav(mtrR, round(RCONST * speed))
            mav(mtrL, round(LCONST * speed))
            gmpc(mtrR)
            gmpc(mtrL)
    freeze(mtrR)
    freeze(mtrL)
    
#STRAIGHT (Overloaded) Takes parameters speed (arbitrary), distance (arbitrary), and right/left motor ports
@dispatch(int, int, int, int)
def straight(speed, dist, mtr_right, mtr_left):
    cmpc(mtr_right)
    cmpc(mtr_left)
    if speed < 0:
        while gmpc(mtr_right) > (dist * -1) and gmpc(mtr_left) > (dist * -1):
            mav(mtr_right, round(RCONST * speed))
            mav(mtr_left, round(LCONST * speed))
            gmpc(mtr_right)
            gmpc(mtr_left)
    else:
        while gmpc(mtr_right) < dist and gmpc(mtr_left) < dist:
            mav(mtr_right, round(RCONST * speed))
            mav(mtr_left, round(LCONST * speed))
            gmpc(mtr_right)
            gmpc(mtr_left)
    freeze(mtr_right)
    freeze(mtr_left)

#STRAIGHT_DEACCEL (EXPERIMENTAL)
def straight_deaccel(speed, dist, deaccel_dist):
    cmpc(mtrR)
    cmpc(mtrL)
    if speed < 0:
        while gmpc(mtrR) > (dist * -1) and gmpc(mtrL) > (dist * -1):
            dist_to_target = dist - (gmpc(mtrR) + gmpc(mtrL)) / 2
            if dist_to_target < deaccel_dist:
                slowdown_factor = dist_to_target / deaccel_dist
                speed *= slowdown_factor
            mav(mtrR, int(speed))
            mav(mtrL, int(speed))
            gmpc(mtrR)
            gmpc(mtrL)
    else:
        while gmpc(mtrR) < dist and gmpc(mtrL) < dist:
            dist_to_target = dist - (gmpc(mtrR) + gmpc(mtrL) / 2)
            if dist_to_target < deaccel_dist:
                slowdown_factor = dist_to_target / deaccel_dist
                speed *= slowdown_factor
            mav(mtrR, int(speed))
            mav(mtrL, int(speed))
            gmpc(mtrR)
            gmpc(mtrL)
            if speed < 1:
                return 0
    freeze(mtrR)
    freeze(mtrL)
    
#LINE_FOLLOW Takes parameters speed (arbitrary), distance (arbitrary), lineside (which side of line you want to follow),
#and sensitivity (the magnitude of the correction it will do to stay on the line)
@dispatch(int, int, str, float)
def line_follow(speed, dist, lineside, sensitivity):
    cmpc(mtrR)
    cmpc(mtrL)
    if speed < 0:
        while gmpc(mtrR) > (dist * -1) and gmpc(mtrL) > (dist * -1):
            mav(mtrR, speed)
            mav(mtrL, speed)
            gmpc(mtrR)
            gmpc(mtrL)
            if str(lineside) == "r":
                reading = analog(RTOPHAT)
                if reading < gray: #on white side
                    mav(mtrR, round(speed * sensitivity))
                if reading > gray: #on black side
                    mav(mtrL, round(speed * sensitivity))
            if str(lineside) == "l":
                reading = analog(LTOPHAT)
                if reading < gray: #on white side
                    mav(mtrL, round(speed * sensitivity))
                if reading > gray: #on black side
                    mav(mtrR, round(speed * sensitivity))
                
    else:
        while gmpc(mtrR) < dist and gmpc(mtrL) < dist:
            mav(mtrR, speed)
            mav(mtrL, speed)
            gmpc(mtrR)
            gmpc(mtrL)
            if str(lineside) == "r":
                reading = analog(RTOPHAT)
                if reading < gray: #on white side
                    mav(mtrR, round(speed * sensitivity))
                if reading > gray: #on black side
                    mav(mtrL, round(speed * sensitivity))
            if str(lineside) == "l":
                reading = analog(LTOPHAT)
                if reading < gray: #on white side
                    mav(mtrL, round(speed * sensitivity))
                if reading > gray: #on black side
                    mav(mtrR, round(speed * sensitivity))
    freeze(mtrR)
    freeze(mtrL)

#LINE_FOLLOW (Overloaded) Takes parameters speed (arbitrary), distance (arbitrary), lineside (which side of line you want to follow),
#and sensitivity (the magnitude of the correction it will do to stay on the line), and the port of the sensor you wish to use,
#this function will not automatically choose which sensor to use based on lineside.
@dispatch(int, int, str, float, int)
def line_follow(speed, dist, lineside, sensitivity, sensor):
    cmpc(mtrR)
    cmpc(mtrL)
    if speed < 0:
        while gmpc(mtrR) > (dist * -1) and gmpc(mtrL) > (dist * -1):
            mav(mtrR, speed)
            mav(mtrL, speed)
            gmpc(mtrR)
            gmpc(mtrL)
            if str(lineside) == "r":
                reading = analog(sensor)
                if reading < gray: #on white side
                    mav(mtrR, round(speed * sensitivity))
                if reading > gray: #on black side
                    mav(mtrL, round(speed * sensitivity))
            if str(lineside) == "l":
                reading = analog(sensor)
                if reading < gray: #on white side
                    mav(mtrL, round(speed * sensitivity))
                if reading > gray: #on black side
                    mav(mtrR, round(speed * sensitivity))
                
    else:
        while gmpc(mtrR) < dist and gmpc(mtrL) < dist:
            mav(mtrR, speed)
            mav(mtrL, speed)
            gmpc(mtrR)
            gmpc(mtrL)
            if str(lineside) == "r":
                reading = analog(sensor)
                if reading < gray: #on white side
                    mav(mtrR, round(speed * sensitivity))
                if reading > gray: #on black side
                    mav(mtrL, round(speed * sensitivity))
            if str(lineside) == "l":
                reading = analog(sensor)
                if reading < gray: #on white side
                    mav(mtrL, round(speed * sensitivity))
                if reading > gray: #on black side
                    mav(mtrR, round(speed * sensitivity))
    freeze(mtrR)
    freeze(mtrL) 

#FIND_LINE Takes parameters speed (arbitrary) and lineside (which side of the line you are approaching from), will pivot towards the line and stop when detected
def find_line(speed, lineside):
    if str(lineside) == "r":
        if analog(RTOPHAT) < gray:
            while analog(RTOPHAT) < gray:
                mav(mtrR, speed)
                mav(mtrL, (speed * -1))
        else:
            while analog(RTOPHAT) > gray:
                mav(mtrR, (speed * -1))
                mav(mtrL, speed)
    if str(lineside) == "l":
        if analog(LTOPHAT) < gray:
            while analog(LTOPHAT) < gray:
                mav(mtrR, (speed * -1))
                mav(mtrL, speed)
        else:
            while analog(LTOPHAT) > gray:
                mav(mtrR, speed)
                mav(mtrL, (speed * -1))
    freeze(mtrR)
    freeze(mtrL)
    
#ALIGN Takes parameters speed (arbitrary), crude horizontal aligning method for small imperfections in alignment
def align(speed):
    while analog(RTOPHAT) < gray and analog(LTOPHAT) < gray:
        mav(mtrR, speed)
        mav(mtrL, speed)
    freeze(mtrR)
    freeze(mtrL)
    if analog(RTOPHAT) < gray:
        while analog(RTOPHAT) < gray:
            mav(mtrR, speed)
    if analog(LTOPHAT) < gray:
        while analog(LTOPHAT) < gray:
            mav(mtrL, speed)
    freeze(mtrR)
    freeze(mtrL)

#SMART_ALIGN Takes parameters speed (arbitrary) and tolerance (how accurate you want the alignment to be), will work for major imperfections generally under
#45 degrees misaligned from the desired line.
def smart_align(speed, tolerance):
    counter1 = -999
    counter2 = 999
    while abs(counter1 - counter2) > tolerance:
        counter1 = 0
        counter2 = 0
        while analog(RTOPHAT) < gray and analog(LTOPHAT) < gray: #Measuring arbitrary value of how far closest sensor is away from line from starting pos
            mav(mtrR, speed)
            mav(mtrL, speed)
            counter1 += 1
        freeze(mtrR)
        freeze(mtrL)
        
        if analog(RTOPHAT) > gray: #if RTOPHAT was first one
            counter2 = counter1
            cmpc(mtrR)
            cmpc(mtrL)
            while analog(LTOPHAT) < gray:
                mav(mtrR, speed)
                mav(mtrL, speed)
                counter2 += 1
            freeze(mtrR)
            freeze(mtrL)
        else: #if LTOPHAT was first one
            counter2 = counter1
            cmpc(mtrR)
            cmpc(mtrL)
            while analog(RTOPHAT) < gray:
                mav(mtrR, speed)
                mav(mtrL, speed)
                counter2 += 1
            freeze(mtrR)
            freeze(mtrL)
        
        #print(counter1)
        #print(counter2)
        straight((speed * -1), round((gmpc(mtrR) + gmpc(mtrL)) / 2))
        align(speed)
        straight((speed * -1), abs(counter1 - counter2))
        msleep(100)
    
#####STRAIGHT MOVEMENTS#####

#####CIRCULAR MOVEMENTS#####
#SPIN Takes parameters speed (arbitrary) and distance (arbitrary), which is the circumference of path, assume positive speed is clockwise
@dispatch(int, int)
def spin(speed, dist):
    cmpc(mtrR)
    cmpc(mtrL)
    if speed < 0:
        while gmpc(mtrR) < dist and gmpc(mtrL) > (dist * -1):
            mav(mtrR, (speed * -1))
            mav(mtrL, speed)
            gmpc(mtrR)
            gmpc(mtrL)
    else:
        while gmpc(mtrR) > (dist * -1) and gmpc(mtrL) < dist:
            mav(mtrR, (speed * -1))
            mav(mtrL, speed)
            gmpc(mtrR)
            gmpc(mtrL)
    freeze(mtrR)
    freeze(mtrL)

#SPIN (Overloaded) Takes parameters speed (arbitrary) and distance (arbitrary), which is the circumference of path, assume positive speed is clockwise, and takes right/left motor ports
@dispatch(int, int, int, int)
def spin(speed, dist, mtr_right, mtr_left):
    cmpc(mtr_right)
    cmpc(mtr_left)
    if speed < 0:
        while gmpc(mtr_right) < dist and gmpc(mtr_left) > (dist * -1):
            mav(mtr_right, (speed * -1))
            mav(mtr_left, speed)
            gmpc(mtr_right)
            gmpc(mtr_left)
    else:
        while gmpc(mtr_right) > (dist * -1) and gmpc(mtr_left) < dist:
            mav(mtr_right, (speed * -1))
            mav(mtr_left, speed)
            gmpc(mtr_right)
            gmpc(mtr_left)
    freeze(mtr_right)
    freeze(mtr_left)
    
#PIVOT Takes parameters speed (arbitrary) and distance (arbitrary), which is the cirumference of the path of the outer wheel, assume positive speed is clockwise
@dispatch(int, int)
def pivot(speed, dist):
    cmpc(mtrR)
    cmpc(mtrL)
    if speed < 0:
        while gmpc(mtrL) > (dist * -1):
            mav(mtrL, speed)
            gmpc(mtrL)
    else:
        while gmpc(mtrR) > (dist * -1):
            mav(mtrR, (speed * -1))
            gmpc(mtrR)
    freeze(mtrR)
    freeze(mtrL)
    
#PIVOT (Overloaded) Takes parameters speed (arbitrary) and distance (arbitrary), which is the cirumference of the path of the outer wheel, assume positive speed is clockwise, and takes right/left motor ports
@dispatch(int, int, int, int)
def pivot(speed, dist, mtr_right, mtr_left):
    cmpc(mtr_right)
    cmpc(mtr_left)
    if speed < 0:
        while gmpc(mtr_left) > (dist * -1):
            mav(mtr_left, speed)
            gmpc(mtr_left)
    else:
        while gmpc(mtr_right) > (dist * -1):
            mav(mtr_right, (speed * -1))
            gmpc(mtr_right)
    freeze(mtr_right)
    freeze(mtr_left)
#####CIRCULAR MOVEMENTS#####
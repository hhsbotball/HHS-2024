#!/usr/bin/python3
import os, sys
sys.path.append("/usr/lib")
#sys.path.append("/home/kipr/.local/lib/python3.9/site-packages/multipledispatch")
#sys.path.append("/home/kipr/Documents/KISS/User/PyTest/src")
from _kipr import *
from movement import *
from servos import *
from mtrsrv import *

#straight_deaccel(500, 5000, 1000)
#straight(1000, 10000)
#find_line(250, 'r')
#line_follow(1000, 3000, 'l', 1.5)
#smart_align(350, 10)
#align(400)
mtrsrv_calibrate(2, 0, 0, 0)
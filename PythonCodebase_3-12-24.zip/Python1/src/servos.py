from _kipr import *
from util import *
import time

#Takes parameters port, position, and buffer (in ms, between each step), maxing out servo pos (0 or 2047) protected
def servo(port, pos, buffer):
    enable_servo(port)
    curr_pos = get_servo_position(port)
    step_size = 2
    
    if pos == 0:
        pos = 5
    if pos == 2047:
        pos = 2042
    
    if curr_pos < pos:
        while curr_pos < pos:
            set_servo_position(port, curr_pos + step_size)
            msleep(buffer)
            curr_pos = get_servo_position(port)
        if curr_pos < pos:
            set_servo_position(port, pos)
    else:
        while curr_pos > pos:
            set_servo_position(port, curr_pos - step_size)
            msleep(buffer)
            curr_pos = get_servo_position(port)
        if curr_pos > pos:
            set_servo_position(port, pos)
            
#(Overloaded) Takes parameters port, position, and buffer (in ms, between each step), maxing out servo pos (0 or 2047) protected, also takes step_size parameter, step size < 2 impossible
def servo(port, pos, buffer, step_size):
    enable_servo(port)
    curr_pos = get_servo_position(port)
    
    if pos == 0:
        pos = 5
    if pos == 2047:
        pos = 2042
    
    if step_size < 2:
        step_size = 2
    
    if curr_pos < pos:
        while curr_pos < pos:
            set_servo_position(port, curr_pos + step_size)
            msleep(buffer)
            curr_pos = get_servo_position(port)
        if curr_pos < pos:
            set_servo_position(port, pos)
    else:
        while curr_pos > pos:
            set_servo_position(port, curr_pos - step_size)
            msleep(buffer)
            curr_pos = get_servo_position(port)
        if curr_pos > pos:
            set_servo_position(port, pos)

#WARNING: This function may turn servo full 180 degrees, make sure it has enough range and is not blocked
#Used to determine the amount of steps/second that servo spins at given buffer (ms)
#Takes parameters servo port, buffer (ms), and timer_reduction, used for faster speeds where servo turns though full range under default 1 second timer, (divides timer)
def calculateStepsPerSecond(port, buffer, timer_reduction):
    step_size = 2
    
    enable_servo(port)
    print("Moving to 0...")
    set_servo_position(port, 0)
    msleep(2000)
    print("Testing...")
    
    current_pos = get_servo_position(port)
    total_steps = 0
    
    start_time = time.time()

    while current_pos < 2047:
        if time.time() - start_time >= (1 / timer_reduction):
            break
        
        set_servo_position(port, current_pos + step_size)
        msleep(buffer)
        total_steps += 2
        current_pos = get_servo_position(port)
    
    disable_servo(port)
    
    result = str(total_steps * timer_reduction) + " steps per second"
    print(result)
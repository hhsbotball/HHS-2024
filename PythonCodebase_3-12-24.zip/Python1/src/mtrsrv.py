from _kipr import *

def mtrsrv_calibrate(mtr, startpos, high_speed, low_speed):
    cmpc(mtr)
    print("Hello World")
    msleep(1000)

#def mtrsrv_move_to():
#def mtrsrv_move_relative_to():